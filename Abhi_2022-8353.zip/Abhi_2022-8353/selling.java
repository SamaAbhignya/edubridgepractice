package onlineclasses;
import java.util.Scanner;
public class selling
{
   public static void main(String args[]) 
   {
    Scanner scanner=new Scanner(System.in);
    System.out.println("Enter the cost price:");
    int cp=scanner.nextInt();
    System.out.println("Enter the selling price:");
    int sp=scanner.nextInt();
    
    int profit,loss;
    if(sp>cp)
    {
    	System.out.println("The seller has made a profit");
    }
    else if(sp<cp)
    {
    	System.out.println("The seller has made a loss");
    }
    else
    {
    	System.out.println("neither profit or loss");
    }
    }
}
