package onlineclasses;
import java.util.Scanner;
public class grosssalary {
public static void main(String args[])
{
	Scanner scanner=new Scanner(System.in);
	//float grossSalary, hra,da;
	System.out.println("enter the salary");
	int salary=scanner.nextInt();
	float grossSalary, hra,da;

	if(salary<1500)
	{
		hra=salary*1/10;
		da=salary*90/100;
		grossSalary=hra+da+salary;
		System.out.println("the gross salary:"+grossSalary);	
	}
	else if(salary>=1500)
	{
		hra=500;
		da=salary*98/100;
		grossSalary=hra+da+salary;
		System.out.println("the gross salary:"+grossSalary);
	}
	else
	{
		System.out.println("invalid input");
	}
}
}
