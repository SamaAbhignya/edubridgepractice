package onlineclasses;
import java.util.Scanner;
public class ifelse2
{
	public static void main(String args[])
	{
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter a value" );
		int num1;
		num1=scanner.nextInt();
		//System.out.println("Enter a value" );
		if(num1<0)
		{
			int abs=-num1;
			System.out.println("the absolute value of num1="+abs);
		}
		else
		{
			System.out.println("the absolute value of num1"+num1);
		}
	}
}
		
	

//}
