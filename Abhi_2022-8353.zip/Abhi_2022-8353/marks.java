package onlineclasses;
import java.util.Scanner;
public class marks {
public static void main(String args[])
{
	Scanner scanner=new Scanner(System.in);
	int eng,math,sci,soci,hin;
	System.out.println("Enter marks of five subjects");
	
	System.out.println("English");
	eng=scanner.nextInt();
	System.out.println("Science");
	sci=scanner.nextInt();
	System.out.println("Maths");
	math=scanner.nextInt();
	System.out.println("Social");
	soci=scanner.nextInt();
	System.out.println("Hindi");
	hin=scanner.nextInt();
	int total=eng+sci+soci+math+hin;
	float percentage=total/5;
	if(percentage>=60 && percentage<=100)
		{
		System.out.println("First division");
		}
	else if(percentage>=50 && percentage<=59)
	{
	System.out.println("Second division");
	}
	else if(percentage>=40 && percentage<=49)
	{
	System.out.println("Third division");
	}
	else if(percentage>0 && percentage<40)
	{
	System.out.println("Fail");
	}
	else
	{
		System.out.println("invalid input");
	}


	
	}
}
