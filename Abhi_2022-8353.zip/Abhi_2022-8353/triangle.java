package onlineclasses;
import java.util.Scanner;
public class triangle {
public static void main(String args[])
{
	Scanner scanner=new Scanner(System.in);
	float num1,num2,num3;
	System.out.println("Enter 1 side of triangle");
	num1=scanner.nextFloat();
	System.out.println("Enter 2 side of triangle");
	num2=scanner.nextFloat();
    System.out.println("Enter 3 side of triangle");
	num3=scanner.nextFloat();

	  if((num1+num2>num3)&&(num2+num3>num1)&&(num3+num1>num2))
      {
		System.out.println("the triangle is valid");
	  }
      
      else 
      {
    	  System.out.println("the triangle is not valid");
      }
}
}
