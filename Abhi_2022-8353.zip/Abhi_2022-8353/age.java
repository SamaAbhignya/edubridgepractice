package onlineclasses;

import java.util.Scanner;

public class age {
public static void main(String args[])
{
  	Scanner scanner=new Scanner(System.in);
  	int RamAge,SulabhAge,AjayAge;
  	System.out.println("Enter the Ram age");
  	RamAge= scanner.nextInt();
  	System.out.println("Enter the Sulabh age");
  	SulabhAge= scanner.nextInt();
  	System.out.println("Enter the Ajay age");
  	AjayAge= scanner.nextInt();
  	if(RamAge<SulabhAge && RamAge<AjayAge) 
  	{
  		System.out.println("the ram is the youngest");
  	}
  	else if(SulabhAge<AjayAge && SulabhAge<RamAge) 
  	{
  		System.out.println("the Sulabh is the youngest");
  	}
  	else if(AjayAge<SulabhAge && AjayAge<RamAge) 
  	{
  		System.out.println("the Ajay is the youngest");
  	}
  	else
  	{
  		System.out.println("invalid age");
  	}
}
}
