package onlineclasses;
import java.util.Scanner;
public class bills 
{
 public static void main(String args[])
 {
	 Scanner scanner=new Scanner(System.in);
	 System.out.println("Enter the number of calls");
	 int calls=scanner.nextInt();
	 double billingamount=0;
	 if(calls>0 && calls<=100)
	 {
		 billingamount=200;
	 }
	 else if(calls>100  && calls<=150)
	 {
		 calls-=100;
		 billingamount=200+(calls*0.60);
	 }
	 else if(calls>150 && calls<=200)
	 {
		 calls-=150;
		 billingamount=200+(50*0.60)+(calls*0.50);
	 }
	 else if(calls>200)
	 {
		 calls-=200;
		 billingamount=200+(50*0.60)+(50*0.50)+(calls*0.40);
	 }
	   System.out.println("the billing amount:"+billingamount);
	   
 }
}
